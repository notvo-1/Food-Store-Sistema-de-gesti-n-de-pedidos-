package com.tp.jpa;

import com.tp.jpa.model.Categoria;
import com.tp.jpa.model.Producto;
import com.tp.jpa.repository.CategoriaRepository;
import com.tp.jpa.repository.ProductoRepository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;

public class Main {
    private static final Scanner sc = new Scanner(System.in);
    private static final CategoriaRepository catRepo = new CategoriaRepository();
    private static final ProductoRepository prodRepo = new ProductoRepository();

    public static void main(String[] args) {
        int opcion;
        do {
            System.out.println("\n=== PARCIAL JPA - MENU PRINCIPAL ===");
            System.out.println("1. ABM Categorias");
            System.out.println("2. ABM Productos");
            System.out.println("3. Reportes");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opcion: ");
            opcion = leerEntero();

            switch (opcion) {
                case 1 -> menuCategorias();
                case 2 -> menuProductos();
                case 3 -> menuReportes();
                case 0 -> System.out.println("Saliendo del sistema...");
                default -> System.out.println("Opcion invalida.");
            }
        } while (opcion != 0);
    }

    // MENU CATEGORIAS
    private static void menuCategorias() {
        int op;
        do {
            System.out.println("\n--- SUBMENU CATEGORIAS ---");
            System.out.println("1. Alta");
            System.out.println("2. Baja Logica");
            System.out.println("3. Modificacion");
            System.out.println("4. Listado");
            System.out.println("0. Volver");
            System.out.print("Seleccione una opcion: ");
            op = leerEntero();

            switch (op) {
                case 1 -> {
                    System.out.print("Ingrese nombre de la categoria: ");
                    String nombre = sc.nextLine().trim();
                    if (nombre.isEmpty()) {
                        System.out.println("Error: El nombre no puede estar vacio.");
                        break;
                    }
                    System.out.print("Ingrese descripcion: ");
                    String desc = sc.nextLine().trim();

                    Categoria cat = Categoria.builder()
                            .nombre(nombre)
                            .descripcion(desc)
                            .eliminado(false)
                            .createdAt(LocalDateTime.now())
                            .build();

                    cat = catRepo.guardar(cat);
                    System.out.println("Categoria guardada con exito. ID generado: " + cat.getId());
                }
                case 2 -> {
                    System.out.print("Ingrese el ID de la categoria a eliminar: ");
                    Long id = leerLong();
                    Optional<Categoria> opt = catRepo.buscarPorId(id);
                    if (opt.isEmpty() || opt.get().isEliminado()) {
                        System.out.println("Error: La categoria con ID " + id + " no existe o ya esta dada de baja.");
                    } else {
                        catRepo.eliminarLogico(id);
                        System.out.println("Categoria '" + opt.get().getNombre() + "' dada de baja correctamente.");
                    }
                }
                case 3 -> {
                    List<Categoria> activas = catRepo.listarActivos();
                    if (activas.isEmpty()) {
                        System.out.println("No hay categorias activas para modificar.");
                        break;
                    }
                    System.out.println("Categorias activas:");
                    activas.forEach(c -> System.out.println("ID: " + c.getId() + " | " + c.getNombre()));

                    System.out.print("Ingrese el ID a modificar: ");
                    Long id = leerLong();
                    Optional<Categoria> opt = catRepo.buscarPorId(id);
                    if (opt.isEmpty() || opt.get().isEliminado()) {
                        System.out.println("Error: ID invalido.");
                        return;
                    }

                    Categoria catActual = opt.get();
                    System.out.println("Valores actuales -> Nombre: " + catActual.getNombre() + " | Descripcion: " + catActual.getDescripcion());
                    System.out.print("Nuevo nombre (dejar vacio para mantener): ");
                    String nuevoNombre = sc.nextLine().trim();
                    System.out.print("Nueva Descripcion (dejar vacio para mantener): ");
                    String nuevaDesc = sc.nextLine().trim();

                    if (!nuevoNombre.isEmpty()) catActual.setNombre(nuevoNombre);
                    if (!nuevaDesc.isEmpty()) catActual.setDescripcion(nuevaDesc);

                    catRepo.guardar(catActual);
                    System.out.println("Categoria actualizada correctamente.");
                }
                case 4 -> {
                    List<Categoria> lista = catRepo.listarActivos();
                    if (lista.isEmpty()) {
                        System.out.println("No hay categorias activas.");
                    } else {
                        System.out.println("\nLISTADO DE CATEGORIAS ACTIVAS:");
                        lista.forEach(c -> System.out.println("ID: " + c.getId() + " - " + c.getNombre() + " (" + c.getDescripcion() + ")"));
                    }
                }
            }
        } while (op != 0);
    }

    // MENU PRODUCTOS
    private static void menuProductos() {
        int op;
        do {
            System.out.println("\n--- SUBMENU PRODUCTOS ---");
            System.out.println("1. Alta");
            System.out.println("2. Baja logica");
            System.out.println("3. Modificacion");
            System.out.println("4. Listado");
            System.out.println("0. Volver");
            System.out.print("Seleccione una opcion: ");
            op = leerEntero();

            switch (op) {
                case 1 -> {
                    List<Categoria> categorias = catRepo.listarActivos();
                    if (categorias.isEmpty()) {
                        System.out.println("Error: Debe crear al menos una categoria primero.");
                        break;
                    }
                    System.out.println("Seleccione una categoria por ID:");
                    categorias.forEach(c -> System.out.println("ID: " + c.getId() + " - " + c.getNombre()));
                    Long catId = leerLong();
                    Optional<Categoria> catOpt = catRepo.buscarPorId(catId);
                    if (catOpt.isEmpty() || catOpt.get().isEliminado()) {
                        System.out.println("Categoria invalida.");
                        break;
                    }

                    System.out.print("Nombre del producto: ");
                    String nombre = sc.nextLine().trim();
                    System.out.print("Descripcion: ");
                    String desc = sc.nextLine().trim();
                    System.out.print("Precio: ");
                    double precio = leerDouble();
                    if (precio <= 0) {
                        System.out.println("Error: El precio debe ser mayor a 0.");
                        break;
                    }
                    System.out.print("Stock: ");
                    int stock = leerEntero();
                    if (stock < 0) {
                        System.out.println("Error: El stock no puede ser negativo.");
                        break;
                    }

                    Producto prod = Producto.builder()
                            .nombre(nombre)
                            .descripcion(desc)
                            .precio(precio)
                            .stock(stock)
                            .disponible(stock > 0)
                            .categoria(catOpt.get())
                            .eliminado(false)
                            .createdAt(LocalDateTime.now())
                            .build();

                    prod = prodRepo.guardar(prod);
                    System.out.println("Producto guardado con exito. ID: " + prod.getId() + " | Categoria: " + catOpt.get().getNombre());
                }
                case 2 -> {
                    System.out.print("Ingrese ID del producto a eliminar: ");
                    Long id = leerLong();
                    Optional<Producto> opt = prodRepo.buscarPorId(id);
                    if (opt.isEmpty() || opt.get().isEliminado()) {
                        System.out.println("Error: El producto no existe o ya esta de baja.");
                    } else {
                        prodRepo.eliminarLogico(id);
                        System.out.println("Producto '" + opt.get().getNombre() + "' eliminado logicamente.");
                    }
                }
                case 3 -> {
                    List<Producto> activos = prodRepo.listarActivos();
                    if (activos.isEmpty()) {
                        System.out.println("No hay productos activos para modificar.");
                        break;
                    }


                    System.out.println("Productos activos disponibles para modificar:");
                    activos.forEach(p -> System.out.println("ID: " + p.getId() + " - " + p.getNombre() + " | Stock: " + p.getStock()));

                    System.out.print("\nIngrese el ID del producto a modificar: ");
                    Long id = leerLong();
                    Optional<Producto> opt = prodRepo.buscarPorId(id);
                    if (opt.isEmpty() || opt.get().isEliminado()) {
                        System.out.println("Error: ID invalido.");
                        return; // CORREGIDO: return seguro en vez de break
                    }

                    Producto p = opt.get();
                    System.out.println("Actuales -> Nombre: " + p.getNombre() + " | Precio: " + p.getPrecio() + " | Stock: " + p.getStock());
                    System.out.print("Nuevo nombre (vacio para mantener): ");
                    String nuevoNombre = sc.nextLine().trim();
                    System.out.print("Nuevo precio (vacio para mantener): ");
                    String precioStr = sc.nextLine().trim();
                    System.out.print("Nuevo stock (vacio para mantener): ");
                    String stockStr = sc.nextLine().trim();

                    if (!nuevoNombre.isEmpty()) p.setNombre(nuevoNombre);
                    if (!precioStr.isEmpty()) {
                        try {
                            double nPrecio = Double.parseDouble(precioStr);
                            if (nPrecio <= 0) {
                                System.out.println("Precio invalido. No se cambio.");
                            } else {
                                p.setPrecio(nPrecio);
                            }
                        } catch (Exception e) {
                            System.out.println("Formato de precio invalido.");
                        }
                    }
                    if (!stockStr.isEmpty()) {
                        try {
                            int nStock = Integer.parseInt(stockStr);
                            if (nStock < 0) {
                                System.out.println("Stock invalido. No se cambio.");
                            } else {
                                p.setStock(nStock);
                                p.setDisponible(nStock > 0);
                            }
                        } catch (Exception e) {
                            System.out.println("Formato de stock invalido.");
                        }
                    }

                    prodRepo.guardar(p);
                    System.out.println("Producto modified de manera correcta.");
                }
                case 4 -> {
                    List<Producto> lista = prodRepo.listarActivos();
                    if (lista.isEmpty()) {
                        System.out.println("No hay productos activos.");
                    } else {
                        System.out.println("\nLISTADO DE PRODUCTOS:");
                        lista.forEach(p -> System.out.println("ID: " + p.getId() + " - " + p.getNombre() + " | $" + p.getPrecio() + " | Stock: " + p.getStock() + " | Cat: " + (p.getCategoria() != null ? p.getCategoria().getNombre() : "Ninguna")));
                    }
                }
            }
        } while (op != 0);
    }

    // REPORTES / CONSULTAS
    private static void menuReportes() {
        System.out.println("\n--- REPORTES ---");
        System.out.println("1. Productos por categoria");
        System.out.println("0. Volver");
        System.out.print("Opcion: ");
        int op = leerEntero();
        if (op == 1) {
            List<Categoria> categorias = catRepo.listarActivos();
            if (categorias.isEmpty()) {
                System.out.println("No hay categorias registradas.");
                return;
            }
            System.out.println("Seleccione una categoria:");
            categorias.forEach(c -> System.out.println("ID: " + c.getId() + " - " + c.getNombre()));
            Long id = leerLong();

            List<Producto> filtrados = prodRepo.buscarPorCategoria(id);
            if (filtrados.isEmpty()) {
                System.out.println("No se encontraron productos activos en esta categoria.");
            } else {
                System.out.println("\nPRODUCTOS EN LA CATEGORIA:");
                filtrados.forEach(p -> System.out.println("ID: " + p.getId() + " - " + p.getNombre() + " | Precio: $" + p.getPrecio() + " | Stock: " + p.getStock()));
            }
        }
    }

    // METODOS HELPERS
    private static int leerEntero() {
        while (true) {
            try {
                return Integer.parseInt(sc.nextLine());
            } catch (NumberFormatException e) {
                System.out.print("Entrada invalida. Ingrese un entero: ");
            }
        }
    }

    private static Long leerLong() {
        while (true) {
            try {
                return Long.parseLong(sc.nextLine());
            } catch (NumberFormatException e) {
                System.out.print("Entrada invalida. Ingrese un ID valido: ");
            }
        }
    }

    private static double leerDouble() {
        while (true) {
            try {
                return Double.parseDouble(sc.nextLine());
            } catch (NumberFormatException e) {
                System.out.print("Entrada invalida. Ingrese un número: ");
            }
        }
    }
}